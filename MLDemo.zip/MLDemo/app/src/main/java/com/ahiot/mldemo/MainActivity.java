package com.ahiot.mldemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.AssetFileDescriptor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;


import org.tensorflow.lite.Interpreter;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

import static java.lang.Math.pow;
import static java.lang.Math.sqrt;


public class MainActivity extends AppCompatActivity {

    Interpreter tflite;
    RadioGroup rgGender,rgSmoke;
    TextView textView;
    float gender, smoker, bmi, children, age, region_val;
    Spinner region;
    EditText edtBmi, edtChild,edtAge;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rgGender = findViewById(R.id.rgGender);
        rgSmoke = findViewById(R.id.rgSmoke);
        textView = findViewById(R.id.text_view_selected);
        region = findViewById(R.id.spinner);
        edtBmi = findViewById(R.id.edtBMI);
        edtChild = findViewById(R.id.edtChild);
        edtAge = findViewById(R.id.edtAge);
        String[] regions = getResources().getStringArray(R.array.region);
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item,regions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        region.setAdapter(adapter);

        try {
            tflite = new Interpreter(loadModelFile());
        }catch (Exception ex){
            ex.printStackTrace();
        }

        Button buttonApply = findViewById(R.id.button_apply);
        buttonApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                standardScaling();
                float prediction=doInference(age,gender,bmi,children,smoker,region_val);
                textView.setText("$"+ Float.toString(prediction));
            }
        });
    }

//do Inference
    private float doInference(float age, float gender, float bmi, float children, float smoker, float region_val) {
        float[][] inputVal = {{age},{gender},{bmi},{children},{smoker},{region_val}};
        float[][] output= new float[1][1];
        tflite.run(inputVal,output);
        float inferredValue= (float) (output[0][0] * sqrt(1.43451672 * pow(10,8)) + 13092.01280714);
        return  inferredValue;
    }
//Code for loading tflite model as a mappedbytebuffer.
// Code taken from https://blog.tensorflow.org/2018/03/using-tensorflow-lite-on-android.html
    private MappedByteBuffer loadModelFile() throws IOException {
        AssetFileDescriptor fileDescriptor=this.getAssets().openFd("ml_model.tflite");
        FileInputStream inputStream=new FileInputStream(fileDescriptor.getFileDescriptor());
        FileChannel fileChannel=inputStream.getChannel();
        long startOffset=fileDescriptor.getStartOffset();
        long declareLength=fileDescriptor.getDeclaredLength();
        return fileChannel.map(FileChannel.MapMode.READ_ONLY,startOffset,declareLength);
    }
//Scaling the input data by mean and variance
    private void standardScaling(){
        int genId = rgGender.getCheckedRadioButtonId();
        int smokeId = rgSmoke.getCheckedRadioButtonId();
        if (genId == R.id.radio_female) {
            gender = (float) ((0-0.49786325)/sqrt(0.249995434));
        } else {
            gender = (float) ((1-0.49786325)/sqrt(0.249995434));
        }
        if (smokeId == R.id.radio_smokeNo) {
            smoker = (float) ((0-0.19978632)/sqrt(0.159871749));
        } else {
            smoker = (float) ((1-0.19978632)/sqrt(0.159871749));
        }

        bmi = (float) ((Float.valueOf(edtBmi.getText().toString()) - 30.61799679)/ sqrt (36.2078891));
        children = (float) ((Float.valueOf(edtChild.getText().toString()) - 1.09294872)/ sqrt(1.44328361));
        age =  (float) ((Float.valueOf(edtAge.getText().toString()) - 39.23611111) / sqrt(197.000875));
        switch (region.getSelectedItem().toString()){
            case "NorthEast": region_val = (float)((0-1.47970085)/sqrt(1.24745119));
                break;
            case "NorthWest": region_val = (float)((1-1.47970085)/sqrt(1.24745119));
                break;
            case "SouthEast": region_val = (float) ((2-1.47970085)/sqrt(1.24745119));
                break;
            case "SouthWest": region_val = (float)((3-1.47970085)/sqrt(1.24745119));
                break;
        }
    }

}